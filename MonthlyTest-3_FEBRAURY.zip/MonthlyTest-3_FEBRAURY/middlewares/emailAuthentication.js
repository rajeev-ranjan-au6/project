const [path, fs, mongoose] = [require('path'), require('fs'), require('mongoose')]
require(path.join(__dirname, '..', 'models', 'db'))
const user = mongoose.model('user')

exports.emailAuthentication = (req, res, next) => {
    // if (user.findOne({ email: { $exists: true } })) return res.render('authentication/register', { err: 'Email already exists!', docTitle: 'REGISTER' })
    // next()

    user.findOne({email : req.body.email}).then(match => {
        if(match) return res.render('authentication/register', {err: 'Email already exists!', docTitle: 'REGISTER'})
        next()
    }).catch(err => console.log(err))
}