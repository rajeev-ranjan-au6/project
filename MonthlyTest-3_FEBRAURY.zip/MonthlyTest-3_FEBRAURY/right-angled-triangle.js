function rat(H,B){
    function sqrt(num){
      return num * num;
    }
    H = sqrt(H), B = sqrt(B)
    function output(){
      return (H + B) ** 0.5
    }
    return O = output()
  }
  rat(5,6)