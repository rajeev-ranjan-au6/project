const [express, mongoose, bcrypt] = [require('express'), require('mongoose'), require('bcryptjs')]
const user = mongoose.model('user')

const router = express.Router()

router.get('/', (req, res) => {
    res.render('authentication/login', { docTitle: 'LOGIN' })
})

router.post('/', (req, res) => {
    const email = req.body.email;
    const password = req.body.password;
    user.findOne({ email: email })
        .then(user => {
            if (!user) {
                return res.render('/users/login', {docTitle : 'LOGIN', err : 'Email Doesn\'t Exists'});
            }
            bcrypt
                .compare(password, user.password)
                .then(doMatch => {
                    if (doMatch) {
                        req.session.isLoggedIn = true;
                        req.session.user = user._id;
                        return req.session.save(err => {
                            console.log(err);
                            res.redirect('/admin/dashboard');
                        });
                    }
                    res.render('authentication/login', {docTitle : 'LOGIN', err : 'Invalid Email or Password'});
                })
                .catch(err => {
                    console.log(err);
                    res.redirect('/users/login');
                });
        })
        .catch(err => console.log(err));
})

module.exports = router