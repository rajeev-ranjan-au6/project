const [express, Joi, fs, path, bcrypt, mongoose] = [require('express'), require('@hapi/joi'), require('fs'), require('path'), require('bcryptjs'), require('mongoose')]
const router = express.Router()

require(path.join(__dirname, '..', 'models', 'db'))

const User = mongoose.model('user')
const Cart = mongoose.model('cart')
const Product = mongoose.model('product')

const userAuthentication = require(path.join(__dirname, '..', 'middlewares', 'sessionAuthenticate'))

router.get('/', (req, res)=>{
    res.render('cart', {docTitle : 'CART'})
})

router.post('/:id', userAuthentication.userAuthentication, (req, res)=>{
    Product.find({_id : req.params.id}).then(data => {
        let cart = new Cart()
        cart.id = req.session.user
        cart.products = cart.products.push({...data})
        cart.qty = cart.qty + 1
        cart.totalprice = cart.totalprice+ +data.pPrice
        cart.save().then(data => {
            console.log(cart.products)
            res.redirect('/cart')
        })
    })
})

module.exports = router