const [express, Joi, fs, path, bcrypt, mongoose] = [require('express'), require('@hapi/joi'), require('fs'), require('path'), require('bcryptjs'), require('mongoose')]
const router = express.Router()

const User = mongoose.model('user')
const emailVerification = require(path.join(__dirname, '..', 'middlewares', 'emailAuthentication'))

router.get('/', (req, res) => {
    res.render('authentication/register', { docTitle: 'REGISTER' })
})

router.post('/', emailVerification.emailAuthentication, (req, res) => {
    const [username, email, password] = [req.body.username, req.body.email, req.body.password]
    const Schema = Joi.object({
        username: Joi.string().min(3).max(20).required(),
        email: Joi.string().required().email({ minDomainSegments: 2, tlds: { allow: ['com', 'net'] } }),
        password: Joi.string().required().pattern(new RegExp('^[a-zA-Z0-9]{3,30}$'))
    })
    const { error, validate } = Schema.validate({ username: username, email: email, password: password })
    if (error) return res.render('authentication/register', { err: error })
    bcrypt.hash(password, 10).then(hashed => {
        let user = new User()
        user.username = username
        user.email = email
        user.password = hashed
        user.save((err, data)=>{
            if(err) return res.render('authentication/register', {docTitle : 'REGISTER', user : data})
            res.redirect('/login')
        })
    })
})

module.exports = router