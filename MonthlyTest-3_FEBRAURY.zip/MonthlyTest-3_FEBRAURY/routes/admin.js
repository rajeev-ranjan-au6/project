const [express, path, multer, mongoose] = [require('express'), require('path'), require('multer'), require('mongoose')]

require(path.join(__dirname, '..', 'models', 'db'))
const User = mongoose.model('user')

let Product = mongoose.model('product')

const router = express.Router()
const userAuthentication = require(path.join(__dirname, '..', 'middlewares', 'sessionAuthenticate'))

router.get('/add-product', userAuthentication.userAuthentication, (req, res) => {
    let user = req.session
    res.render('admin/add-product', { docTitle: 'ADD PRODUCTS', id: user.id })
})

router.get('/view-product', (req, res) => {
    Product.find().then(data => {
        res.render('admin/view-product', { docTitle: 'VIEW-PRODUCTS', data : data })
    }).catch(err => console.log(err))
})
router.get('/dashboard', userAuthentication.userAuthentication, (req, res) => {
    User.find({id : req.session.user}).then(data => {
        res.render('admin/dashboard', {docTitle : 'DASHBOARD', data : data.username })
    }).catch(err => console.log(err))
})

router.post('/add-product', (req, res) => {
    let products = new Product()
    products.pId = req.session.user
    products.pImage = req.body.pImage
    products.pName = req.body.pName
    products.pPrice = req.body.pPrice
    products.pDesc = req.body.pDesc
    products.save((err, data) => {
        if (err) return res.render('admin/add-product', { err: 'Error adding products', docTitle: 'ADD-PRODUCTS' })
        res.redirect('/admin/add-product')
    })

})

router.get('/update', (req, res)=> {
    
})

router.post('/logout')
module.exports = router