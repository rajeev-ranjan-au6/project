var express = require('express');
var router = express.Router();
var mongoose = require('mongoose')
let Product = mongoose.model('product')
/* GET home page. */
router.get('/', function(req, res, next) {
  Product.find().then(data => {
    res.render('index', { docTitle: 'Ecommerce', data : data });
  }).catch(err => console.log(err))
});

module.exports = router;
