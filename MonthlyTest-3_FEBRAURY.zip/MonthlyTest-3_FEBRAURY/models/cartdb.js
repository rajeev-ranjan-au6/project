const mongoose = require('mongoose')

require('./db')

const schema = new mongoose.Schema({
    products: [
        {
          product: { type: Object, required: true },
          quantity: { type: Number, required: true }
        }
      ],
      user: {
        email: {
          type: String,
          required: true
        }
      }
})

const cart = mongoose.model('cart', schema)

module.exports = cart