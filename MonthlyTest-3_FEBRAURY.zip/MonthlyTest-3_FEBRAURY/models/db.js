const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/shoppy', { useNewUrlParser: true, useUnifiedTopology: true }).then(res => console.log(`DB Connected Successfully`)).catch(err => `Error Connecting DB ${err}`)

require('./usersdb')

require('./productsdb')

require('./cartdb')