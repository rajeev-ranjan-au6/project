const mongoose = require('mongoose')

require('./db')

const schema = new mongoose.Schema({
    pId : {
        type : String,
        required : true,
    },
    pImage: {
        type: String,
        required: true,
        trim: true
    }, pName: {
        type: String,
        required: true,
        trim: true
    }, pPrice: {
        type: String,
        required: true,
        trim: true
    }, pDesc: {
        type: String,
        trim: true,
        required: true
    }
})

const product = mongoose.model('product', schema)

module.exports = product