// Importing nodemialer
const [nodemailer] = [require("nodemailer")];

const { EMAIL, EMAILPASSWORD } = process.env;

module.exports = {
  async registerMail(email, secretToken) {
    try {
      let transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
          user: EMAIL,
          pass: EMAILPASSWORD
        }
      });
      const mailOptions = {
        from: EMAIL,
        to: email,
        subject: "Account Verification",
        html: `<h1>Thanks for registering - <span style='color : #433166'>JOLLY<span> <span style='color : #dca42d'>PARTY</span></h1>
        <p style='margin-bottom : 20px;'>To continue click on the link below to verify email</p>
          <a href="https://salty-castle-33988.herokuapp.com/api/v1/users/verify_email/${secretToken}?email=${email}" 
          style='text-decoration : none; background : #433166; color : #dca42d; padding : 15px 45px;margin-top : 20px; font-size : 14px;'>click here to verify</a>`
      };
      await transporter.sendMail(mailOptions);
    } catch (error) {
      console.log(error);
    }
  }
}
