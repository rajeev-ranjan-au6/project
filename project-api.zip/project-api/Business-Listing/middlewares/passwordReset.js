// Importing nodemialer
const [nodemailer, dotenv] = [require("nodemailer"), require('dotenv').config()];

const { EMAIL, EMAILPASSWORD } = process.env;

module.exports = async (email, token) => {
  try {
    let transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: EMAIL,
        pass: EMAILPASSWORD
      }
    });
    const mailOptions = {
      from: EMAIL,
      to: email,
      subject: "Password Reset",
      html: `<h1>We'll never let make things complicate. - <span style='color : #433166'>JOLLY<span> <span style='color : #dca42d'>PARTY</span></h1>
      <p style='margin-bottom : 20px;'>Here is your password, Go through this password</p>
        <p style='text-decoration : none; background : #433166; color : #dca42d; padding : 15px 45px;margin-top : 20px; font-size : 14px;'>${token}</p>`
    };
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.log(error);
  }
};
