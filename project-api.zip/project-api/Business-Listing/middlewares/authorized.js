const [path, jwt, dotenv] = [
  require("path"),
  require("jsonwebtoken"),
  require("dotenv").config()
];

// Mongoose collections paths
const User = require("../models/Users");
const Admin = require("../models/Admin");
const async = require("../middlewares/asyncHandler");
exports.authorized = async(async (req, res, next) => {
  // if (!req.header("Authorization")) {
  //   return res
  //     .status(401)
  //     .json({ success: false, error: `You're not authorized` });
  // }
  // try {
  //   const decoded = jwt.verify(req.header("Authorization"), process.env.JWT_SECRET);
  //   req.user = await User.findById(decoded.id);
  //   next();
  // } catch (err) {
  //   return res
  //     .status(401)
  //     .json({ success: false, error: `You're not authorized ${err}` });
  // }
  let authtoken = req.header("Authorization");
  if (authtoken) {
    const decoded = jwt.verify(authtoken, process.env.JWT_SECRET)
    req.user = await User.findById(decoded.id) || Admin.findById(decoded.id);
    next()
    // fs.readFile(userjsonpath, { encoding: "utf-8" }, (err, users) => {
      // if (err) return res.status(500).send("Unknown error");
      // let jsusers = JSON.parse(users);
      // let user = jsusers.find(user => user.token === authtoken);
      // if (!user) return res.status(400).send("Invalid Credentials");
      // jwt.verify(user.token, 'sriksha', (err, payload)=>{
      //     if(err) return res.status(401).send('Token Experied')
      //     req.user = user
      //     next()
      // })
    // });
  } else {
    res.status(400).send("User Not Found");
  }
});
exports.roleauthor = (...roles) => {
  return (req, res, next) => {
    // console.log(req.user)
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        error: `You're not authorized to perform this action`
      });
    }
    next();
  };
};
