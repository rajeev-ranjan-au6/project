// Initializing Express Router
const [router, path] = [require("express").Router(), require("path")];

// Importing Middlewares
const emailexists = require("../middlewares/emailExists");
const { authorized, roleauthor } = require("../middlewares/authorized");
const emailVerified = require("../middlewares/emailVerified");
const accountStatus = require("../middlewares/accountstatus");

// Importing Controller Routes
const {
  Register,
  Login,
  Logout,
  Me,
  forgotPassword,
  verifyForgotPasswordToken,
  modifyPassword,
  getBusinessLists,
  placeOrder,
  postRatings,
  deleteAccount,
  updateProfile,
  mainSearch,
  vendorByCategory
} = require("../controllers/users");
// Register Routes
router.route("/me").get(authorized, Me);
router.route("/register").post(emailexists,accountStatus, Register);
// Login Routes
router.route("/login").post(emailVerified,accountStatus, Login);
// Logout Routes
router.route("/logout").post(authorized, Logout).put( deleteAccount);
// Update Profile
router.route('/:id').put(authorized, updateProfile)
// forgot password
router.route("/forgot-password").post(emailVerified, forgotPassword);
// verify forgot password token and create a new password
router.route("/create-password/:id").put(verifyForgotPasswordToken);
// Change password
router.route("/modify-password/:passwordToken").put(authorized, modifyPassword);
// View all clients
router.route("/view-all").get(getBusinessLists);
// Vendor By Id
router.route('/:category').get(vendorByCategory)
// Main search
router.route('/view-all/main-search').get(mainSearch)
// Request vendor
router.route("/send-request/:id").post(placeOrder);
// search for a vendor
router.route("/client/search").get();
// post a rating
router.route('/ratings/:id').post(authorized, postRatings)
// Exporting router module
module.exports = router;
