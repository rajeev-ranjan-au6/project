// Initializing Express Router
const [router, path] = [require("express").Router(), require("path")];

// Importing Middlewares
const { authorized, roleauthor } = require("../middlewares/adminAuthorized");

const {
  Register,
  getBusinessLists,
  Login,
  Logout,
  getRequests,
  getSingleRequest,
  deleteSingleRequest,
  fetchAllclients,
  createBusiness,
  deleteSingleUser,
  fetchAllvendors,
  fetchAllservices,
  getProfile,
  modifyPassword
} = require("../controllers/admin");
const emailexists = require("../middlewares/emailExists");
// Register Routes
router.route("/register").post( Register);
// Login Routes
router.route("/login").post(Login);
// Logout Routes
router.route("/logout").post( Logout);
// Get Profile
router.route('/profile/:id').get(getProfile)
// // Get All Activation list
router.route("/activate").get( getRequests);
// Get Single Activation List
router.route("/activate/:id").get( getSingleRequest);
// // Delete Activation Request
router.route("/remove/vendor/:id").delete( deleteSingleRequest);
// Get All Business list
router.route("/fetch/businesslist").get( getBusinessLists);
// Get All Client list
router.route("/fetch/clients").get( fetchAllclients);
// Get All Vendor list
router.route("/fetch/vendors").get( fetchAllvendors);
// Get All Service list
router.route("/fetch/services").get( fetchAllservices);
// forgot password
router.route("/modify-password/:passwordToken").put(modifyPassword);
// Remove client
router.route("/remove/user/:id").delete( deleteSingleUser);
// Create Business
router.route("/create-business").post( roleauthor("admin"), createBusiness);
// Exporting router module
module.exports = router;
