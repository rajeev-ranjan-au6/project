const [router, path, multer] = [
  require("express").Router(),
  require("path"),
  require("multer"),
];
const { authorized, roleauthor } = require(path.join(
  __dirname,
  "..",
  "middlewares",
  "authorized"
));

const upload = require("../multerSingle");
const uploadArray = require("../multerArray");

// vendor controller
const {
  getOrders,
  getBusinessListByID,
  createBusinessList,
  updateBusinessListByID,
  deleteBusinessListByID,
  bannerImage,
  imageCollections,
  deleteGallery,
  acceptOrders,
  getReviews,
  getRecommendations,
  getRatings,
  getProfile
} = require("../controllers/vendors");

// routes Middlewares
router.use("/:id/services", require("./services"));

// routes
router
  .route("/")
  .post(authorized, roleauthor("admin", "vendor"), createBusinessList);

router.route("/orders/:id").get(getOrders).post(authorized, acceptOrders);
router.route('/profile/:id').get(getProfile)
router
  .route("/:id")
  .get(getBusinessListByID)
  .put(authorized, roleauthor("admin", "vendor"), updateBusinessListByID)
  .delete(authorized, roleauthor("admin", "vendor"), deleteBusinessListByID);
router.route('/reviews/:id').get(authorized, getReviews)
router
  .route("/image_banner/:id")
  .put(authorized, roleauthor("admin", "vendor"), upload, bannerImage);
router.route('/ratings/:id').get(authorized, getRatings)
router
  .route("/image_collections/:id")
  .put(authorized, roleauthor("admin", "vendor"), uploadArray, imageCollections)
  .delete(authorized, roleauthor("admin", "vendor"), deleteGallery);
// Get recommendations
router.route('/recommendations/:id').get(getRecommendations)

// router.route("image_collections/:id").put(uploadArray, imageCollections);

module.exports = router;
