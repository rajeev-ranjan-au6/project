
// Importing app module from index.js
const app = require("./index");





const PORT = process.env.PORT || 3000

// Environment Variables
  app.listen(PORT, () =>
  console.log(`Server Connected At Port ${PORT} in ${process.env.NODE_ENV} environment`))
