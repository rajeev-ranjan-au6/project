// NPM modules
const [path, Joi, multer, cloudinary] = [
  require("path"),
  require("@hapi/joi"),
  require("multer"),
  require("cloudinary"),
];
// Middlewares/custom files import
const [order, BusinessList, User, async, uploadSingle, uploadArray] = [
  require("../models/Orders"),
  require("../models/BusinessLists"),
  require("../models/Users"),
  require("../middlewares/asyncHandler"),
  require("../multerSingle"),
  require("../multerArray"),
];
// cloudinary
require("../cloudinary");
exports.getProfile = async(async (req, res, next) => {
  const user = await BusinessList.findOne({user : req.params.id});
  if (!user) {
    return res.status(400).json({
      success: false,
      error: `No valid details found with requested id ${req.params.id}`,
    });
  }
  res
    .status(200)
    .json({ success: true, data: user });
});
// Fetch business by id
exports.getBusinessListByID = async(async (req, res, next) => {
  const user = await BusinessList.findById(req.params.id);
  if (!user) {
    return res.status(400).json({
      success: false,
      error: `No valid details found with requested id ${req.params.id}`,
    });
  }
  res
    .status(200)
    .json({ success: true, data: user });
});
// Get reviews
exports.getReviews = async(async (req, res, next) => {
  const user = await User.findById(req.params.id);
  if (!user) {
    return res.status(400).json({
      success: false,
      error: `No valid resource found with requested id ${req.params.id}`,
    });
  }
  var businesslist = await BusinessList.findOne({ user });
  if (!businesslist) {
    businesslist = []
    return res.status(400).json({ success: true, count: businesslist.length, data: businesslist,
    });
  }
  res
    .status(200)
    .json({ success: true, count: businesslist.length, data: businesslist });
});
exports.getRatings = async(async (req, res, next) => {
  const user = await User.findById(req.params.id);
  if (!user) {
    return res.status(400).json({
      success: false,
      error: `No valid resource found with requested id ${req.params.id}`,
    });
  }
  let businesslist = await BusinessList.findOne({ user });
  if (!user) {
    businesslist = {rating : []}
    return res.status(400).json({ success: true, count: businesslist.length, data: businesslist,
    });
  }
  const rating = businesslist.rating;
  console.log(rating);
  res
    .status(200)
    .json({ success: true, count: businesslist.length, data: businesslist });
});
// Get requests
exports.getOrders = async(async (req, res, next) => {
  const orders = await order.find({ vendorId: req.params.id });
  if (!orders)
    return res.status(400).json({ success: false, error: `You've No Orders.` });
  return res.status(200).json({ success: true, data: orders });
});
// Accept orders
exports.acceptOrders = async(async (req, res, next) => {
  const orderId = req.params.id;
  if (!orderId)
    return res.status(406).json({
      success: false,
      error: `No valid resource found with requested id ${orderId}`,
    });
  const order = await Order.find({ vendorId: orderId });
  if (!order)
    return res.status(404).json({
      success: false,
      count: 0,
      error: `No valid resource found with requested id.`,
    });
  order.isAccepted = true;
  await order.save();
  return res
    .status(200)
    .json({ success: true, message: `Congrats, You'd accepted an order.` });
});
// Create a business
exports.createBusinessList = async(async (req, res, next) => {
  // declaring variables
  const {
    name,
    email,
    category,
    city,
    state,
    pincode,
    area,
    dno,
    street,
    address,
    district,
    price,
    primaryContact,
    description,
    user,
  } = req.body;
  //validation using joi
  const Schema = Joi.object({
    // name: Joi.string().required().max(50),
    category: Joi.string().required().max(15),
    city: Joi.string().required().min(4).max(15),
    state: Joi.string().required().min(4).max(15),
    area: Joi.string().required().min(4).max(20),
    dno: Joi.string().min(5).max(12).required(),
    street: Joi.string().required().min(4).max(15),
    address: Joi.string().required().min(4).max(100),
    district: Joi.string().required().min(4).max(15),
    price: Joi.number().required().min(3),
    primaryContact: Joi.number().required().min(10),
    pincode: Joi.string().required().min(6).max(10),
    email: Joi.string().email({
      minDomainSegments: 2,
      tlds: { allow: ["com", "net"] },
    }),
  });
  const { error, result } = Schema.validate({
    // name: name,
    category: category,
    city: city,
    state: state,
    area: area,
    dno: dno,
    street: street,
    address: address,
    district: district,
    price: price,
    primaryContact: primaryContact,
    pincode: pincode,
    email: email,
  });
  if (error) {
    return res.status(400).json({ success: false, error: error.message });
  } else {
    const existeduser = await BusinessList.findOne({ user: req.user.id });
    // console.log(req.user)
    if (existeduser && req.user.role !== "admin") {
      return res.status(406).json({
        success: false,
        error: `You're not authorized to create another business, Please contact admin for further details`,
      });
    }
    const data = new BusinessList({
      user,
      name,
      category,
      price,
      primaryContact,
      email,
      description,
      city,
      state,
      area,
      dno,
      street,
      address,
      district,
      pincode,
    });
    await data.save();
    res.status(201).json({
      success: true,
      message: `Congrats You've successfully posted your business, Your business is under review, we'll get back to you in soon.`,
    });
  }
});
// update business by id
exports.updateBusinessListByID = async(async (req, res, next) => {
  let businesslist = await User.findById(req.params.id);
  console.log(req.user.id);
  if (!businesslist) {
    return res.status(400).json({
      success: false,
      error: `No valid resource found with requested id ${req.params.id}`,
    });
  }
  businesslist = await BusinessList.findOneAndUpdate(
    { user: req.params.id },
    req.body,
    {
      new: true,
      runvalidators: true,
    }
  );
  res.status(201).json({ success: true, data: businesslist });
});
// Updating Banner Image
exports.bannerImage = async(async (req, res, next) => {
  uploadSingle(req, res, (err) => {
    if (err) {
      return res.status(400).json({ msg: err });
    }
  });
  // const businesslist = await BusinessList.findById(req.params.id);
  // if (!businesslist) {
  //   return res.status(400).json({
  //     success: false,
  //     error: `No valid resource found with requested id ${req.params.id}`,
  //   });
  // } else {
  //   if (
  //     businesslist.user.toString() !== req.user.id &&
  //     req.user.role !== "admin"
  //   ) {
  //     return res.status(403).json({
  //       success: false,
  //       error: `Requested user ${req.user.id} is not authorized to perform this action`,
  //     });
  //   }
  try {
    const imagedata = await cloudinary.v2.uploader.upload(req.file.path);
    const successdata = await BusinessList.findOneAndUpdate(
      { user: req.params.id },
      { $set: { banner: imagedata.secure_url } },
      { new: true, runvalidators: true }
    );
    // const successdata = await BusinessList.findByIdAndUpdate(
    //   req.params.id,
    //   { $set: { banner: imagedata.secure_url } },
    //   { new: true, runvalidators: true }
    // );
    return res.status(200).json({ success: true, data: successdata });
  } catch (err) {
    return res.status(401).json({ success: false, err });
  }
});
// Updating Image Collections
exports.imageCollections = async(async (req, res, next) => {
  uploadSingle(req, res, (err) => {
    if (err) {
      return res.status(400).json({ msg: err });
    }
  });
  const businesslist = await BusinessList.findById(req.params.id);
  if (!businesslist) {
    return res.status(400).json({
      success: false,
      error: `No valid resource found with requested id ${req.params.id}`,
    });
  } else {
    if (
      businesslist.user.toString() !== req.user.id &&
      req.user.role !== "admin"
    ) {
      return res.status(403).json({
        success: false,
        error: `Requested user ${req.user.id} is not authorized to perform this action`,
      });
    }
    if (businesslist.gallery.length === 6) {
      return res.status(406).json({
        success: false,
        error: `You'd reached the maximum galllery limit.`,
      });
    }
      const imagedata = await cloudinary.v2.uploader.upload(req.file.path);
      businesslist.gallery.push(imagedata.secure_url);
      await businesslist.save();
      return res.status(200).json({ success: true, data: successdata });
  }
});
// Delete gallery images
exports.deleteGallery = async(async (req, res, next) => {
  const businessid = await BusinessList.findById(req.params.id);
  if (!businessid) {
    return res.status(400).json({
      success: false,
      error: `No valid resource found with requested id ${req.params.id}`,
    });
  } else {
    if (
      businessid.user.toString() !== req.user.id &&
      req.user.role !== "admin"
    ) {
      return res.status(403).json({
        success: false,
        error: `Requested user ${req.user.id} is not authorized to perform this action`,
      });
    }
    let data = businessid.gallery;
    let arr = req.query.gallery.split(",");
    var difference = data.filter((x) => arr.indexOf(x) === -1);
    console.log(difference);
    let user = await BusinessList.findById(req.params.id);
    let updated = await BusinessList.findByIdAndUpdate(req.params.id, {
      $set: { gallery: difference },
    });
    res.status(201).json({ success: true, data: updated });
  }
});
// Recommendations
exports.getRecommendations = async(async (req, res, next) => {
  let [vendorId, arr] = [req.params.id, []];
  let getCategory = await BusinessList.findById(vendorId);
  let vendors = await BusinessList.find({
    category: getCategory.category,
  }).sort({ avgRating: -1 });
  return res
    .status(200)
    .json({ success: false, count: vendors.length, data: vendors.slice(0, 5) });
});
// Delete business by id
exports.deleteBusinessListByID = async(async (req, res, next) => {
  const businesslist = await BusinessList.findById(req.params.id);
  if (!businesslist) {
    return res.status(400).json({
      success: false,
      error: `No valid response for id ${req.params.id}`,
    });
  }
  if (
    businesslist.user.toString() !== req.user.id &&
    req.user.role !== "admin"
  ) {
    return res.status(403).json({
      success: false,
      error: `Requested user ${req.user.id} is not authorized to perform this action`,
    });
  }
  businesslist.remove();
  res.status(200).json({ success: true, data: [] });
});
