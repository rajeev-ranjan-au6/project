// Requiring NPM Modules
const [express, path, fs, dotenv, mongoose, morgan, cookieParser, sanitize, helmet, xss, rateLimit, hpp, compression, cors] = [
  require("express"),
  require("path"),
  require("fs"),
  require("dotenv"),
  require("mongoose"),
  require("morgan"),
  require('cookie-parser'),
  require('express-mongo-sanitize'),
  require('helmet'),
  require('xss-clean'),
  require('express-rate-limit'),
  require('hpp'),
  require('compression'),
  require('cors')
];
dotenv.config();

const { MONGODB_URI } = process.env;
// Mongoose Connection
mongoose
  .connect(`${MONGODB_URI}`, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
  })
  .then(() => {console.log("DB Connected Successfully!!!");})
  .catch((err) => console.log(err));


// Initializing App variable
const app = express();

// Adding Express Middleware Functions
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(morgan("dev"));
app.use(cookieParser())
app.use(sanitize())
app.use(cors())
app.use(helmet())
app.use(xss())
app.use(hpp())
app.use(compression())
const limiter = rateLimit({
  windowMs: 10 * 60 * 1000, // 10 mins
  max: 100
});
app.use(limiter);


// Fixing cors errors problems
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization"
  );
  if (req.method === "Options") {
    res.header("Access-Control-Allow-Methods", "GET, PUT, PATCH, DELETE, POST");
    return res.status(200).json({});
  }
  next();
});


app.get("/",(req,res)=>res.send({message:"Hi, This is API Application"}))


// Adding Custom Middlewares
app.use(
  "/api/v1/business/",
  require("./routes/vendors")
);
app.use(
  "/api/v1/services",
  require("./routes/services")
);
app.use("/api/v1/users", require("./routes/users"));
app.use(
  "/api/v1/users/verify_email",
  require("./routes/verifyEmail")
);
app.use('/api/v1/admin', require('./routes/admin'))
app.use('/', require('./routes/index'))

// Error Handling
app.use((req, res, next) => {
  const error = new Error("Page Not Found!");
  error.status = 404;
  next(error);
});
app.use((error, req, res, next) => {
  res.status(error.status || 500);
  res.json({
    error: error.message
  });
});

module.exports = app;
