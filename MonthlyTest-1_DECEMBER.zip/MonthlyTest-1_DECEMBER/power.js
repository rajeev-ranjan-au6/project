function power(a,b){
    let result = 1;
    for(let i = 1; i<=b; i++){
      result *= a;
    }
    return result;
  }
  power(5,5)