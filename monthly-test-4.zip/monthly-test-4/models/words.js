const [mongoose] = [require('mongoose')]

const schema = mongoose.Schema({
    word : {
        type : String,
        required: true
    },rank : {
        type : Number,
        required: true
    }
})


module.exports = mongoose.model('Word', schema)