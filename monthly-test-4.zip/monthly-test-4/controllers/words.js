var fs = require('fs')
var path = require('path');

// mongodb collectionsOperation
const Word = require(path.join(__dirname, '..', 'models', 'words'))


exports.words = async (req, res, next) => {
    const pageNumber = req.params.page
    const query = req.query.word
    const words = await Word.find({word : {$regex : query, $options: "i"}}).sort({rank: -1}).skip((pageNumber-1)* 25).limit(25)
    res.json(words)
}