var express = require('express');
var router = express.Router();
var fs = require('fs')
var path = require('path');

// controllers
const controller = require(path.join(__dirname,'..', 'controllers', 'words'))

// mongodb collectionsOperation
const words = require(path.join(__dirname, '..', 'models', 'words'))
/* GET home page. */
router.get('/', (req, res,next)=>{
  res.render('index',{title:'Home'})
});
router.get('/search/:page', controller.words);

module.exports = router;
